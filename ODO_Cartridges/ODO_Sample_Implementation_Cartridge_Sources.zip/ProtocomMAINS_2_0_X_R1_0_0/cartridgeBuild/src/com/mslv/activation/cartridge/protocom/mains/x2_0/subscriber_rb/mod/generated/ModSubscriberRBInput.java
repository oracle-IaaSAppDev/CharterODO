/*
 * WARNING: DO NOT MODIFY THE CONTENTS OF THIS FILE.
 *
 *    This file contains generated code.  Any changes to the file may be overwritten.
 * All process logic should be implemented in the related Processor class and 
 * non-generated supporting classes.
 *
 *    Do not place this file under source control.  Doing so may prevent proper generation
 * and synchronization of this file with the supporting model.
 *
 *=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 * 2001 MetaSolv Software, Inc. All rights reserved. MetaSolv Software, the MetaSolv
 * logo,
 * MetaSolv Solution, Framework for Success, MetaSolv QuickStart, MetaSolv eService,
 * MetaSolv Field Operations Portal, Rapid Results, and MetaSolv Network and
 * Service Planning are trademarks of MetaSolv Software, Inc. The MetaSolv Network
 * and Service Planning subsystem is based on STAR INFORMATIC S.A.'s GIS technology.
 * MetaSolv is a trademark registered in the United States of America by MetaSolv
 * Software, Inc.
 * All other trademarks are property of their respective owners. Any rights not
 * expressly
 * granted herein are reserved. Information contained herein is subject to change
 * without notice .
 * =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 */
package com.mslv.activation.cartridge.protocom.mains.x2_0.subscriber_rb.mod.generated;

import java.util.Properties;

/**
 * 
 * 
 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
 */
public class ModSubscriberRBInput {

	// Repeat for each Parameter
	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_SU = "OLD_SU";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_su;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String RETURN_DATA_PREFIX = "RETURN_DATA_PREFIX";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String return_data_prefix;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_COL_LV = "OLD_COL_LV";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_col_lv;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_MBA_LV = "OLD_MBA_LV";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_mba_lv;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_INDEX = "OLD_INDEX";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_index;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_T2 = "OLD_T2";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_t2;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_N2 = "OLD_N2";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_n2;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_SSF = "OLD_SSF";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_ssf;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_MN = "OLD_MN";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_mn;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_AN = "OLD_AN";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_an;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_PORTED_CARRIER = "OLD_PORTED_CARRIER";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_ported_carrier;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_WBC_LV = "OLD_WBC_LV";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_wbc_lv;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_AT = "OLD_AT";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_at;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_SEQ_NO = "OLD_SEQ_NO";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_seq_no;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_IMSI = "OLD_IMSI";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_imsi;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String MCLI = "MCLI";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String mcli;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_SAM_LV = "OLD_SAM_LV";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_sam_lv;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_PREPAID = "OLD_PREPAID";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_prepaid;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_BAR_CN = "OLD_BAR_CN";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_bar_cn;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_PORTED_OUT = "OLD_PORTED_OUT";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_ported_out;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_PCC_LV = "OLD_PCC_LV";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_pcc_lv;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_SPID = "OLD_SPID";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_spid;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_TS = "OLD_TS";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_ts;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_TD = "OLD_TD";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_td;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_REDIR_NO = "OLD_REDIR_NO";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_redir_no;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_NETWORK_TYPE = "OLD_NETWORK_TYPE";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_network_type;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String OLD_DR = "OLD_DR";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String old_dr;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public ModSubscriberRBInput() {
		super();
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public ModSubscriberRBInput(Properties parms) {
		this(parms, "");
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public ModSubscriberRBInput(Properties parms, String prefix) {
		super();

		old_su = parms.getProperty(prefix + OLD_SU);

		return_data_prefix = parms.getProperty(prefix + RETURN_DATA_PREFIX);

		old_col_lv = parms.getProperty(prefix + OLD_COL_LV);

		old_mba_lv = parms.getProperty(prefix + OLD_MBA_LV);

		old_index = parms.getProperty(prefix + OLD_INDEX);

		old_t2 = parms.getProperty(prefix + OLD_T2);

		old_n2 = parms.getProperty(prefix + OLD_N2);

		old_ssf = parms.getProperty(prefix + OLD_SSF);

		old_mn = parms.getProperty(prefix + OLD_MN);

		old_an = parms.getProperty(prefix + OLD_AN);

		old_ported_carrier = parms.getProperty(prefix + OLD_PORTED_CARRIER);

		old_wbc_lv = parms.getProperty(prefix + OLD_WBC_LV);

		old_at = parms.getProperty(prefix + OLD_AT);

		old_seq_no = parms.getProperty(prefix + OLD_SEQ_NO);

		old_imsi = parms.getProperty(prefix + OLD_IMSI);

		mcli = parms.getProperty(prefix + MCLI);

		old_sam_lv = parms.getProperty(prefix + OLD_SAM_LV);

		old_prepaid = parms.getProperty(prefix + OLD_PREPAID);

		old_bar_cn = parms.getProperty(prefix + OLD_BAR_CN);

		old_ported_out = parms.getProperty(prefix + OLD_PORTED_OUT);

		old_pcc_lv = parms.getProperty(prefix + OLD_PCC_LV);

		old_spid = parms.getProperty(prefix + OLD_SPID);

		old_ts = parms.getProperty(prefix + OLD_TS);

		old_td = parms.getProperty(prefix + OLD_TD);

		old_redir_no = parms.getProperty(prefix + OLD_REDIR_NO);

		old_network_type = parms.getProperty(prefix + OLD_NETWORK_TYPE);

		old_dr = parms.getProperty(prefix + OLD_DR);

	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_SU() {
		return (old_su != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_SU() {
		return old_su;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_SU(String old_su) {
		this.old_su = old_su;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasRETURN_DATA_PREFIX() {
		return (return_data_prefix != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getRETURN_DATA_PREFIX() {
		return return_data_prefix;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setRETURN_DATA_PREFIX(String return_data_prefix) {
		this.return_data_prefix = return_data_prefix;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_COL_LV() {
		return (old_col_lv != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_COL_LV() {
		return old_col_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_COL_LV(String old_col_lv) {
		this.old_col_lv = old_col_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_MBA_LV() {
		return (old_mba_lv != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_MBA_LV() {
		return old_mba_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_MBA_LV(String old_mba_lv) {
		this.old_mba_lv = old_mba_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_INDEX() {
		return (old_index != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_INDEX() {
		return old_index;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_INDEX(String old_index) {
		this.old_index = old_index;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_T2() {
		return (old_t2 != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_T2() {
		return old_t2;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_T2(String old_t2) {
		this.old_t2 = old_t2;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_N2() {
		return (old_n2 != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_N2() {
		return old_n2;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_N2(String old_n2) {
		this.old_n2 = old_n2;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_SSF() {
		return (old_ssf != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_SSF() {
		return old_ssf;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_SSF(String old_ssf) {
		this.old_ssf = old_ssf;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_MN() {
		return (old_mn != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_MN() {
		return old_mn;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_MN(String old_mn) {
		this.old_mn = old_mn;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_AN() {
		return (old_an != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_AN() {
		return old_an;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_AN(String old_an) {
		this.old_an = old_an;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_PORTED_CARRIER() {
		return (old_ported_carrier != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_PORTED_CARRIER() {
		return old_ported_carrier;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_PORTED_CARRIER(String old_ported_carrier) {
		this.old_ported_carrier = old_ported_carrier;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_WBC_LV() {
		return (old_wbc_lv != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_WBC_LV() {
		return old_wbc_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_WBC_LV(String old_wbc_lv) {
		this.old_wbc_lv = old_wbc_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_AT() {
		return (old_at != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_AT() {
		return old_at;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_AT(String old_at) {
		this.old_at = old_at;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_SEQ_NO() {
		return (old_seq_no != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_SEQ_NO() {
		return old_seq_no;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_SEQ_NO(String old_seq_no) {
		this.old_seq_no = old_seq_no;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_IMSI() {
		return (old_imsi != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_IMSI() {
		return old_imsi;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_IMSI(String old_imsi) {
		this.old_imsi = old_imsi;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasMCLI() {
		return (mcli != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getMCLI() {
		return mcli;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setMCLI(String mcli) {
		this.mcli = mcli;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_SAM_LV() {
		return (old_sam_lv != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_SAM_LV() {
		return old_sam_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_SAM_LV(String old_sam_lv) {
		this.old_sam_lv = old_sam_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_PREPAID() {
		return (old_prepaid != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_PREPAID() {
		return old_prepaid;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_PREPAID(String old_prepaid) {
		this.old_prepaid = old_prepaid;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_BAR_CN() {
		return (old_bar_cn != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_BAR_CN() {
		return old_bar_cn;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_BAR_CN(String old_bar_cn) {
		this.old_bar_cn = old_bar_cn;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_PORTED_OUT() {
		return (old_ported_out != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_PORTED_OUT() {
		return old_ported_out;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_PORTED_OUT(String old_ported_out) {
		this.old_ported_out = old_ported_out;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_PCC_LV() {
		return (old_pcc_lv != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_PCC_LV() {
		return old_pcc_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_PCC_LV(String old_pcc_lv) {
		this.old_pcc_lv = old_pcc_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_SPID() {
		return (old_spid != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_SPID() {
		return old_spid;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_SPID(String old_spid) {
		this.old_spid = old_spid;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_TS() {
		return (old_ts != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_TS() {
		return old_ts;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_TS(String old_ts) {
		this.old_ts = old_ts;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_TD() {
		return (old_td != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_TD() {
		return old_td;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_TD(String old_td) {
		this.old_td = old_td;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_REDIR_NO() {
		return (old_redir_no != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_REDIR_NO() {
		return old_redir_no;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_REDIR_NO(String old_redir_no) {
		this.old_redir_no = old_redir_no;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_NETWORK_TYPE() {
		return (old_network_type != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_NETWORK_TYPE() {
		return old_network_type;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_NETWORK_TYPE(String old_network_type) {
		this.old_network_type = old_network_type;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasOLD_DR() {
		return (old_dr != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getOLD_DR() {
		return old_dr;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setOLD_DR(String old_dr) {
		this.old_dr = old_dr;
	}

	/**
	 * This method is used to determine if the bean is populated.  The method returns true if
	 * all properties of the bean are not present, or if the properties of the bean cannot be determined.
	 *
	 * Compound entries without named members cannot be validated for presence.  As a result, this 
	 * method assumes they are not present and factors it into the overall result.
	 *
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean isEmpty() {
		boolean isEmpty = true;

		isEmpty = isEmpty && (old_su == null);

		isEmpty = isEmpty && (return_data_prefix == null);

		isEmpty = isEmpty && (old_col_lv == null);

		isEmpty = isEmpty && (old_mba_lv == null);

		isEmpty = isEmpty && (old_index == null);

		isEmpty = isEmpty && (old_t2 == null);

		isEmpty = isEmpty && (old_n2 == null);

		isEmpty = isEmpty && (old_ssf == null);

		isEmpty = isEmpty && (old_mn == null);

		isEmpty = isEmpty && (old_an == null);

		isEmpty = isEmpty && (old_ported_carrier == null);

		isEmpty = isEmpty && (old_wbc_lv == null);

		isEmpty = isEmpty && (old_at == null);

		isEmpty = isEmpty && (old_seq_no == null);

		isEmpty = isEmpty && (old_imsi == null);

		isEmpty = isEmpty && (mcli == null);

		isEmpty = isEmpty && (old_sam_lv == null);

		isEmpty = isEmpty && (old_prepaid == null);

		isEmpty = isEmpty && (old_bar_cn == null);

		isEmpty = isEmpty && (old_ported_out == null);

		isEmpty = isEmpty && (old_pcc_lv == null);

		isEmpty = isEmpty && (old_spid == null);

		isEmpty = isEmpty && (old_ts == null);

		isEmpty = isEmpty && (old_td == null);

		isEmpty = isEmpty && (old_redir_no == null);

		isEmpty = isEmpty && (old_network_type == null);

		isEmpty = isEmpty && (old_dr == null);

		return isEmpty;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String toString() {
		StringBuffer buff = new StringBuffer();

		buff.append("Parameters:\n");

		buff.append("old_su = " + getOLD_SU() + "\n");

		buff.append("return_data_prefix = " + getRETURN_DATA_PREFIX() + "\n");

		buff.append("old_col_lv = " + getOLD_COL_LV() + "\n");

		buff.append("old_mba_lv = " + getOLD_MBA_LV() + "\n");

		buff.append("old_index = " + getOLD_INDEX() + "\n");

		buff.append("old_t2 = " + getOLD_T2() + "\n");

		buff.append("old_n2 = " + getOLD_N2() + "\n");

		buff.append("old_ssf = " + getOLD_SSF() + "\n");

		buff.append("old_mn = " + getOLD_MN() + "\n");

		buff.append("old_an = " + getOLD_AN() + "\n");

		buff.append("old_ported_carrier = " + getOLD_PORTED_CARRIER() + "\n");

		buff.append("old_wbc_lv = " + getOLD_WBC_LV() + "\n");

		buff.append("old_at = " + getOLD_AT() + "\n");

		buff.append("old_seq_no = " + getOLD_SEQ_NO() + "\n");

		buff.append("old_imsi = " + getOLD_IMSI() + "\n");

		buff.append("mcli = " + getMCLI() + "\n");

		buff.append("old_sam_lv = " + getOLD_SAM_LV() + "\n");

		buff.append("old_prepaid = " + getOLD_PREPAID() + "\n");

		buff.append("old_bar_cn = " + getOLD_BAR_CN() + "\n");

		buff.append("old_ported_out = " + getOLD_PORTED_OUT() + "\n");

		buff.append("old_pcc_lv = " + getOLD_PCC_LV() + "\n");

		buff.append("old_spid = " + getOLD_SPID() + "\n");

		buff.append("old_ts = " + getOLD_TS() + "\n");

		buff.append("old_td = " + getOLD_TD() + "\n");

		buff.append("old_redir_no = " + getOLD_REDIR_NO() + "\n");

		buff.append("old_network_type = " + getOLD_NETWORK_TYPE() + "\n");

		buff.append("old_dr = " + getOLD_DR() + "\n");

		return buff.toString();
	}

}

