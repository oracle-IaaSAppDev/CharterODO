/*
 * WARNING: DO NOT MODIFY THE CONTENTS OF THIS FILE.
 *
 *    This file contains generated code.  Any changes to the file may be overwritten.
 * All process logic should be implemented in the related Processor class and 
 * non-generated supporting classes.
 *
 *    Do not place this file under source control.  Doing so may prevent proper generation
 * and synchronization of this file with the supporting model.
 *
 *=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 * 2001 MetaSolv Software, Inc. All rights reserved. MetaSolv Software, the MetaSolv
 * logo,
 * MetaSolv Solution, Framework for Success, MetaSolv QuickStart, MetaSolv eService,
 * MetaSolv Field Operations Portal, Rapid Results, and MetaSolv Network and
 * Service Planning are trademarks of MetaSolv Software, Inc. The MetaSolv Network
 * and Service Planning subsystem is based on STAR INFORMATIC S.A.'s GIS technology.
 * MetaSolv is a trademark registered in the United States of America by MetaSolv
 * Software, Inc.
 * All other trademarks are property of their respective owners. Any rights not
 * expressly
 * granted herein are reserved. Information contained herein is subject to change
 * without notice .
 * =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 */
package com.mslv.activation.cartridge.protocom.mains.x2_0.subscriber.del.generated;

import java.util.Properties;

/**
 * 
 * 
 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
 */
public class DelSubscriberInput {

	// Repeat for each Parameter
	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String RETURN_DATA_PREFIX = "RETURN_DATA_PREFIX";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String return_data_prefix;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String MCLI = "MCLI";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String mcli;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String MN = "MN";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String mn;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public DelSubscriberInput() {
		super();
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public DelSubscriberInput(Properties parms) {
		this(parms, "");
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public DelSubscriberInput(Properties parms, String prefix) {
		super();

		return_data_prefix = parms.getProperty(prefix + RETURN_DATA_PREFIX);

		mcli = parms.getProperty(prefix + MCLI);

		mn = parms.getProperty(prefix + MN);

	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasRETURN_DATA_PREFIX() {
		return (return_data_prefix != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getRETURN_DATA_PREFIX() {
		return return_data_prefix;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setRETURN_DATA_PREFIX(String return_data_prefix) {
		this.return_data_prefix = return_data_prefix;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasMCLI() {
		return (mcli != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getMCLI() {
		return mcli;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setMCLI(String mcli) {
		this.mcli = mcli;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasMN() {
		return (mn != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getMN() {
		return mn;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setMN(String mn) {
		this.mn = mn;
	}

	/**
	 * This method is used to determine if the bean is populated.  The method returns true if
	 * all properties of the bean are not present, or if the properties of the bean cannot be determined.
	 *
	 * Compound entries without named members cannot be validated for presence.  As a result, this 
	 * method assumes they are not present and factors it into the overall result.
	 *
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean isEmpty() {
		boolean isEmpty = true;

		isEmpty = isEmpty && (return_data_prefix == null);

		isEmpty = isEmpty && (mcli == null);

		isEmpty = isEmpty && (mn == null);

		return isEmpty;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String toString() {
		StringBuffer buff = new StringBuffer();

		buff.append("Parameters:\n");

		buff.append("return_data_prefix = " + getRETURN_DATA_PREFIX() + "\n");

		buff.append("mcli = " + getMCLI() + "\n");

		buff.append("mn = " + getMN() + "\n");

		return buff.toString();
	}

}

