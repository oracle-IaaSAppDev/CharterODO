/*
 * WARNING: DO NOT MODIFY THE CONTENTS OF THIS FILE.
 *
 *    This file contains generated code.  Any changes to the file may be overwritten.
 * All process logic should be implemented in the related Processor class and 
 * non-generated supporting classes.
 *
 *    Do not place this file under source control.  Doing so may prevent proper generation
 * and synchronization of this file with the supporting model.
 *
 *=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 * 2001 MetaSolv Software, Inc. All rights reserved. MetaSolv Software, the MetaSolv
 * logo,
 * MetaSolv Solution, Framework for Success, MetaSolv QuickStart, MetaSolv eService,
 * MetaSolv Field Operations Portal, Rapid Results, and MetaSolv Network and
 * Service Planning are trademarks of MetaSolv Software, Inc. The MetaSolv Network
 * and Service Planning subsystem is based on STAR INFORMATIC S.A.'s GIS technology.
 * MetaSolv is a trademark registered in the United States of America by MetaSolv
 * Software, Inc.
 * All other trademarks are property of their respective owners. Any rights not
 * expressly
 * granted herein are reserved. Information contained herein is subject to change
 * without notice .
 * =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 */
package com.mslv.activation.cartridge.protocom.mains.x2_0.subscriber.mod.generated;

import java.util.Properties;

/**
 * 
 * 
 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
 */
public class ModSubscriberInput {

	// Repeat for each Parameter
	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String PCC_LV = "PCC_LV";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String pcc_lv;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String RETURN_DATA_PREFIX = "RETURN_DATA_PREFIX";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String return_data_prefix;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String TD = "TD";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String td;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String PREPAID = "PREPAID";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String prepaid;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String PORTED_OUT = "PORTED_OUT";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String ported_out;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String TS = "TS";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String ts;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String SEQ_NO = "SEQ_NO";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String seq_no;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String SU = "SU";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String su;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String NETWORK_TYPE = "NETWORK_TYPE";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String network_type;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String SPID = "SPID";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String spid;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String DR = "DR";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String dr;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String COL_LV = "COL_LV";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String col_lv;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String AT = "AT";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String at;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String PORTED_CARRIER = "PORTED_CARRIER";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String ported_carrier;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String INDEX = "INDEX";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String index;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String REDIR_NO = "REDIR_NO";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String redir_no;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String SAM_LV = "SAM_LV";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String sam_lv;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String MCLI = "MCLI";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String mcli;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String IMSI = "IMSI";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String imsi;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String MN = "MN";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String mn;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String N2 = "N2";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String n2;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String SSF = "SSF";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String ssf;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String MBA_LV = "MBA_LV";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String mba_lv;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String T2 = "T2";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String t2;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String WBC_LV = "WBC_LV";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String wbc_lv;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String BAR_CN = "BAR_CN";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String bar_cn;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private static final String AN = "AN";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	private String an;

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public ModSubscriberInput() {
		super();
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public ModSubscriberInput(Properties parms) {
		this(parms, "");
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public ModSubscriberInput(Properties parms, String prefix) {
		super();

		pcc_lv = parms.getProperty(prefix + PCC_LV);

		return_data_prefix = parms.getProperty(prefix + RETURN_DATA_PREFIX);

		td = parms.getProperty(prefix + TD);

		prepaid = parms.getProperty(prefix + PREPAID);

		ported_out = parms.getProperty(prefix + PORTED_OUT);

		ts = parms.getProperty(prefix + TS);

		seq_no = parms.getProperty(prefix + SEQ_NO);

		su = parms.getProperty(prefix + SU);

		network_type = parms.getProperty(prefix + NETWORK_TYPE);

		spid = parms.getProperty(prefix + SPID);

		dr = parms.getProperty(prefix + DR);

		col_lv = parms.getProperty(prefix + COL_LV);

		at = parms.getProperty(prefix + AT);

		ported_carrier = parms.getProperty(prefix + PORTED_CARRIER);

		index = parms.getProperty(prefix + INDEX);

		redir_no = parms.getProperty(prefix + REDIR_NO);

		sam_lv = parms.getProperty(prefix + SAM_LV);

		mcli = parms.getProperty(prefix + MCLI);

		imsi = parms.getProperty(prefix + IMSI);

		mn = parms.getProperty(prefix + MN);

		n2 = parms.getProperty(prefix + N2);

		ssf = parms.getProperty(prefix + SSF);

		mba_lv = parms.getProperty(prefix + MBA_LV);

		t2 = parms.getProperty(prefix + T2);

		wbc_lv = parms.getProperty(prefix + WBC_LV);

		bar_cn = parms.getProperty(prefix + BAR_CN);

		an = parms.getProperty(prefix + AN);

	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasPCC_LV() {
		return (pcc_lv != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getPCC_LV() {
		return pcc_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setPCC_LV(String pcc_lv) {
		this.pcc_lv = pcc_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasRETURN_DATA_PREFIX() {
		return (return_data_prefix != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getRETURN_DATA_PREFIX() {
		return return_data_prefix;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setRETURN_DATA_PREFIX(String return_data_prefix) {
		this.return_data_prefix = return_data_prefix;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasTD() {
		return (td != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getTD() {
		return td;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setTD(String td) {
		this.td = td;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasPREPAID() {
		return (prepaid != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getPREPAID() {
		return prepaid;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setPREPAID(String prepaid) {
		this.prepaid = prepaid;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasPORTED_OUT() {
		return (ported_out != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getPORTED_OUT() {
		return ported_out;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setPORTED_OUT(String ported_out) {
		this.ported_out = ported_out;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasTS() {
		return (ts != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getTS() {
		return ts;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setTS(String ts) {
		this.ts = ts;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasSEQ_NO() {
		return (seq_no != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getSEQ_NO() {
		return seq_no;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setSEQ_NO(String seq_no) {
		this.seq_no = seq_no;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasSU() {
		return (su != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getSU() {
		return su;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setSU(String su) {
		this.su = su;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasNETWORK_TYPE() {
		return (network_type != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getNETWORK_TYPE() {
		return network_type;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setNETWORK_TYPE(String network_type) {
		this.network_type = network_type;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasSPID() {
		return (spid != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getSPID() {
		return spid;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setSPID(String spid) {
		this.spid = spid;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasDR() {
		return (dr != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getDR() {
		return dr;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setDR(String dr) {
		this.dr = dr;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasCOL_LV() {
		return (col_lv != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getCOL_LV() {
		return col_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setCOL_LV(String col_lv) {
		this.col_lv = col_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasAT() {
		return (at != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getAT() {
		return at;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setAT(String at) {
		this.at = at;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasPORTED_CARRIER() {
		return (ported_carrier != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getPORTED_CARRIER() {
		return ported_carrier;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setPORTED_CARRIER(String ported_carrier) {
		this.ported_carrier = ported_carrier;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasINDEX() {
		return (index != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getINDEX() {
		return index;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setINDEX(String index) {
		this.index = index;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasREDIR_NO() {
		return (redir_no != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getREDIR_NO() {
		return redir_no;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setREDIR_NO(String redir_no) {
		this.redir_no = redir_no;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasSAM_LV() {
		return (sam_lv != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getSAM_LV() {
		return sam_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setSAM_LV(String sam_lv) {
		this.sam_lv = sam_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasMCLI() {
		return (mcli != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getMCLI() {
		return mcli;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setMCLI(String mcli) {
		this.mcli = mcli;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasIMSI() {
		return (imsi != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getIMSI() {
		return imsi;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setIMSI(String imsi) {
		this.imsi = imsi;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasMN() {
		return (mn != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getMN() {
		return mn;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setMN(String mn) {
		this.mn = mn;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasN2() {
		return (n2 != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getN2() {
		return n2;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setN2(String n2) {
		this.n2 = n2;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasSSF() {
		return (ssf != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getSSF() {
		return ssf;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setSSF(String ssf) {
		this.ssf = ssf;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasMBA_LV() {
		return (mba_lv != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getMBA_LV() {
		return mba_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setMBA_LV(String mba_lv) {
		this.mba_lv = mba_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasT2() {
		return (t2 != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getT2() {
		return t2;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setT2(String t2) {
		this.t2 = t2;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasWBC_LV() {
		return (wbc_lv != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getWBC_LV() {
		return wbc_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setWBC_LV(String wbc_lv) {
		this.wbc_lv = wbc_lv;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasBAR_CN() {
		return (bar_cn != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getBAR_CN() {
		return bar_cn;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setBAR_CN(String bar_cn) {
		this.bar_cn = bar_cn;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean hasAN() {
		return (an != null);
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String getAN() {
		return an;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void setAN(String an) {
		this.an = an;
	}

	/**
	 * This method is used to determine if the bean is populated.  The method returns true if
	 * all properties of the bean are not present, or if the properties of the bean cannot be determined.
	 *
	 * Compound entries without named members cannot be validated for presence.  As a result, this 
	 * method assumes they are not present and factors it into the overall result.
	 *
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public boolean isEmpty() {
		boolean isEmpty = true;

		isEmpty = isEmpty && (pcc_lv == null);

		isEmpty = isEmpty && (return_data_prefix == null);

		isEmpty = isEmpty && (td == null);

		isEmpty = isEmpty && (prepaid == null);

		isEmpty = isEmpty && (ported_out == null);

		isEmpty = isEmpty && (ts == null);

		isEmpty = isEmpty && (seq_no == null);

		isEmpty = isEmpty && (su == null);

		isEmpty = isEmpty && (network_type == null);

		isEmpty = isEmpty && (spid == null);

		isEmpty = isEmpty && (dr == null);

		isEmpty = isEmpty && (col_lv == null);

		isEmpty = isEmpty && (at == null);

		isEmpty = isEmpty && (ported_carrier == null);

		isEmpty = isEmpty && (index == null);

		isEmpty = isEmpty && (redir_no == null);

		isEmpty = isEmpty && (sam_lv == null);

		isEmpty = isEmpty && (mcli == null);

		isEmpty = isEmpty && (imsi == null);

		isEmpty = isEmpty && (mn == null);

		isEmpty = isEmpty && (n2 == null);

		isEmpty = isEmpty && (ssf == null);

		isEmpty = isEmpty && (mba_lv == null);

		isEmpty = isEmpty && (t2 == null);

		isEmpty = isEmpty && (wbc_lv == null);

		isEmpty = isEmpty && (bar_cn == null);

		isEmpty = isEmpty && (an == null);

		return isEmpty;
	}

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public String toString() {
		StringBuffer buff = new StringBuffer();

		buff.append("Parameters:\n");

		buff.append("pcc_lv = " + getPCC_LV() + "\n");

		buff.append("return_data_prefix = " + getRETURN_DATA_PREFIX() + "\n");

		buff.append("td = " + getTD() + "\n");

		buff.append("prepaid = " + getPREPAID() + "\n");

		buff.append("ported_out = " + getPORTED_OUT() + "\n");

		buff.append("ts = " + getTS() + "\n");

		buff.append("seq_no = " + getSEQ_NO() + "\n");

		buff.append("su = " + getSU() + "\n");

		buff.append("network_type = " + getNETWORK_TYPE() + "\n");

		buff.append("spid = " + getSPID() + "\n");

		buff.append("dr = " + getDR() + "\n");

		buff.append("col_lv = " + getCOL_LV() + "\n");

		buff.append("at = " + getAT() + "\n");

		buff.append("ported_carrier = " + getPORTED_CARRIER() + "\n");

		buff.append("index = " + getINDEX() + "\n");

		buff.append("redir_no = " + getREDIR_NO() + "\n");

		buff.append("sam_lv = " + getSAM_LV() + "\n");

		buff.append("mcli = " + getMCLI() + "\n");

		buff.append("imsi = " + getIMSI() + "\n");

		buff.append("mn = " + getMN() + "\n");

		buff.append("n2 = " + getN2() + "\n");

		buff.append("ssf = " + getSSF() + "\n");

		buff.append("mba_lv = " + getMBA_LV() + "\n");

		buff.append("t2 = " + getT2() + "\n");

		buff.append("wbc_lv = " + getWBC_LV() + "\n");

		buff.append("bar_cn = " + getBAR_CN() + "\n");

		buff.append("an = " + getAN() + "\n");

		return buff.toString();
	}

}

