/*
 * WARNING: DO NOT MODIFY THE CONTENTS OF THIS FILE.
 *
 *    This file contains generated code.  Any changes to the file may be overwritten.
 * All process logic should be implemented in the related Processor class and 
 * non-generated supporting classes.
 *
 *    Do not place this file under source control.  Doing so may prevent proper generation
 * and synchronization of this file with the supporting model.
 *
 *=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 * 2001 MetaSolv Software, Inc. All rights reserved. MetaSolv Software, the MetaSolv
 * logo,
 * MetaSolv Solution, Framework for Success, MetaSolv QuickStart, MetaSolv eService,
 * MetaSolv Field Operations Portal, Rapid Results, and MetaSolv Network and
 * Service Planning are trademarks of MetaSolv Software, Inc. The MetaSolv Network
 * and Service Planning subsystem is based on STAR INFORMATIC S.A.'s GIS technology.
 * MetaSolv is a trademark registered in the United States of America by MetaSolv
 * Software, Inc.
 * All other trademarks are property of their respective owners. Any rights not
 * expressly
 * granted herein are reserved. Information contained herein is subject to change
 * without notice .
 * =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 */
package com.mslv.activation.cartridge.protocom.mains.x2_0.subscriber.mod.generated;


import com.mslv.studio.activation.implementation.IBaseSystemParameters;

/**
 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
 */
public interface ISystemParameters extends IBaseSystemParameters {

}