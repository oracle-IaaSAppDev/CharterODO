/*
 * WARNING: DO NOT MODIFY THE CONTENTS OF THIS FILE.
 *
 *    This file contains generated code.  Any changes to the file may be overwritten.
 * All process logic should be implemented in the related Processor class and 
 * non-generated supporting classes.
 *
 *    Do not place this file under source control.  Doing so may prevent proper generation
 * and synchronization of this file with the supporting model.
 *
 *=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 * 2001 MetaSolv Software, Inc. All rights reserved. MetaSolv Software, the MetaSolv
 * logo,
 * MetaSolv Solution, Framework for Success, MetaSolv QuickStart, MetaSolv eService,
 * MetaSolv Field Operations Portal, Rapid Results, and MetaSolv Network and
 * Service Planning are trademarks of MetaSolv Software, Inc. The MetaSolv Network
 * and Service Planning subsystem is based on STAR INFORMATIC S.A.'s GIS technology.
 * MetaSolv is a trademark registered in the United States of America by MetaSolv
 * Software, Inc.
 * All other trademarks are property of their respective owners. Any rights not
 * expressly
 * granted herein are reserved. Information contained herein is subject to change
 * without notice .
 * =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
 */
package com.mslv.activation.cartridge.protocom.mains.x2_0.subscriber_rb_upstream.mod.generated;

import com.mslv.studio.activation.implementation.IActionProcessor;
import com.mslv.studio.activation.implementation.IConnectionHandler;
import com.mslv.studio.activation.implementation.IExitType;


/**
 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
 */
public interface ModSubscriberRBUpstreamProcessorInterface extends
		IActionProcessor {

	/*
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public static final String VENDOR = "PROTOCOM";
	public static final String TECHNOLOGY = "MAINS";
	public static final String SOFTWARE_LOAD = "2-0";
	public static final String ACTION = "MOD";
	public static final String ENTITY = "SUBSCRIBER-RB-UPSTREAM";

	public static final String PARAMETER_PREFIX = "MOD_SUBSCRIBER-RB-UPSTREAM_";

	public static final String PARAMETER_ERROR = PARAMETER_PREFIX + "ERROR";
	public static final String PARAMETER_VENDOR = PARAMETER_PREFIX + "VENDOR";
	public static final String PARAMETER_TECHNOLOGY = PARAMETER_PREFIX
			+ "TECHNOLOGY";
	public static final String PARAMETER_SOFTWARE_LOAD = PARAMETER_PREFIX
			+ "SOFTWARE_LOAD";
	public static final String PARAMETER_ACTION = PARAMETER_PREFIX + "ACTION";
	public static final String PARAMETER_ENTITY = PARAMETER_PREFIX + "ENTITY";

	/**
	 * @generated DO NOT MODIFY THE CONTENTS OF THIS FILE.
	 */
	public void execute(ModSubscriberRBUpstreamInput bean,
			ModSubscriberRBUpstreamOutput output,
			IConnectionHandler connection, IExitType exitType,
			ISystemParameters systemParameters) throws Exception;

}

