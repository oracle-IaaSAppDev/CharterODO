/*
 * Copyright (c) 2017, Oracle and/or its affiliates. All rights reserved.
 */
package oracle.communications.osm.uim.mdb;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class GenericSOAPConnection {
	private static final Log log = LogFactory.getLog(GenericSOAPConnection.class);
	
	public HttpURLConnection getConnection(String baseURL, String action, String method){
		if (log.isDebugEnabled()) {
		    log.debug("Entering into getConnection()");
		}
		HttpURLConnection httpConn=null;
		try{
			URL url = new URL(baseURL);
	        URLConnection connection = url.openConnection();
	        httpConn = (HttpURLConnection) connection;	               
	        httpConn.setRequestProperty("Content-Type",UIMConstants.contentType);
	        httpConn.setRequestProperty("SOAPAction",action);
	        httpConn.setRequestMethod(method);
	        httpConn.setDoOutput(true);
	        httpConn.setDoInput(true);
		} catch(MalformedURLException me) {
			me.printStackTrace();
			try {
				throw me;
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		} catch(IOException ie) {
			ie.printStackTrace();
			try {
				throw ie;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (log.isDebugEnabled()) {
		   log.debug("Leaving from getConnection()");
		}
        return httpConn;
	}
}
