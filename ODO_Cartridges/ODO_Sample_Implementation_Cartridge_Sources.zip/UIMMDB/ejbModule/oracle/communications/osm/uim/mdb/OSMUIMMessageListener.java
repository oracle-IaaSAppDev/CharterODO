/*
 * Copyright (c) 2017, Oracle and/or its affiliates. All rights reserved.
 */
package oracle.communications.osm.uim.mdb;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.util.Properties;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJBContext;
import javax.ejb.MessageDriven;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sun.mail.iap.ConnectionException;


/**
 * Message-Driven Bean implementation class for: OSMUIMMessageListener
 *
 */
@MessageDriven(
		activationConfig = { 
				@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
				@ActivationConfigProperty(propertyName = "destination", propertyValue = "inventorySFWSRequestQueue")
				}, mappedName="inventorySFWSRequestQueue")
public class OSMUIMMessageListener implements MessageListener {
	private static final Log log = LogFactory.getLog(OSMUIMMessageListener.class);
	private Properties prop = new Properties();
	private EJBContext context;
    /**
     * Default constructor. 
     */
    public OSMUIMMessageListener() {
    	loadPropertyFile();
    }
	
	/**
     * @see MessageListener#onMessage(Message)
     */
    public void onMessage(Message message) {
    	if (log.isDebugEnabled()) {
  	       log.debug("Entering into OSMUIMMessageListener onMessage()");
  	   	}
    	Connection connection = null;
    	Session session = null;
        try {   
	    		InitialContext ctx=new InitialContext();
	            ConnectionFactory factory = (ConnectionFactory)ctx.lookup("inventoryConnectionFactory");
	            Queue queue = (Queue) ctx.lookup("inventorySFWSResponseQueue");
	            connection = factory.createConnection();
	            connection.start(); 
	            session = connection.createSession(false,QueueSession.AUTO_ACKNOWLEDGE);
	            MessageProducer producer = session.createProducer(queue);
	            String response = getResponse(message);
	            TextMessage msg = session.createTextMessage(response);
	            msg.setJMSCorrelationID(message.getJMSCorrelationID());
	            producer.send(msg);
        	} catch (JMSException e) {
        		context.setRollbackOnly();
        		try {
					throw new JMSException("JMSException occured :: "+e);
				} catch (JMSException e1) {
					e1.printStackTrace();
				}
        		
        	} catch (IOException e) {
        		context.setRollbackOnly();
        		try {
        			throw new IOException("IOException occured :: "+e);
        		} catch (IOException e1) {
					e1.printStackTrace();
				}
        	} catch (NamingException e) {
        		context.setRollbackOnly();
        		try {
					throw new NamingException("NamingException occured :: "+e);
				} catch (NamingException e1) {
					e1.printStackTrace();
				}
        	} catch (ConnectionException e) {
        		context.setRollbackOnly();
        		try {
					throw new ConnectionException("ConnectionException occured :: "+e);
				} catch (ConnectionException e1) {
					e1.printStackTrace();
				}
        	} finally {
    	        if (session != null) {
    	        	try {
						session.close();
					} catch (JMSException e) {
						e.printStackTrace();
					}
    	        }
    	        if (connection != null) {
    	        	try {
						connection.close();
					} catch (JMSException e) {
						e.printStackTrace();
					}
      	        }
        	}
        if (log.isDebugEnabled()) {
   	       log.debug("Leaving from OSMUIMMessageListener onMessage()");
   	   	}
    }
    
	private Properties loadPropertyFile(){
		if (log.isDebugEnabled()) {
	         log.debug("Entering into OSMUIMMessageListener loadPropertyFile()");
	   	}
		try{
			InputStream inputStream = getClass().getClassLoader().getResourceAsStream(UIMConstants.configFileName);
			if (inputStream != null) {
				prop.load(inputStream);
				if (log.isDebugEnabled()) {
			         log.debug("UIMConstants.baseUrl ::: "+prop.getProperty(UIMConstants.baseUrl));
			         log.debug("UIMConstants.action ::: "+prop.getProperty(UIMConstants.action));
			         log.debug("UIMConstants.method ::: "+prop.getProperty(UIMConstants.method));
			         log.debug("UIMConstants.username ::: "+prop.getProperty(UIMConstants.username));
			         log.debug("UIMConstants.password ::: "+prop.getProperty(UIMConstants.password));
			   	}
			} else {
				throw new FileNotFoundException("property file '" + UIMConstants.configFileName + "' not found in the classpath");
			}
		} catch(IOException ioe){
			ioe.printStackTrace();
		}
		if (log.isDebugEnabled()) {
	         log.debug("Leaving from OSMUIMMessageListener loadPropertyFile()");
	   	}
		return prop;
	}
	
	private String getResponse(Message uimRequestXml) throws ConnectionException,JMSException,IOException{
		 if (log.isDebugEnabled()) {
			 log.debug("Entering into OSMUIMMessageListener getResponse()");
		 }
		 GenericSOAPConnection connection = new GenericSOAPConnection();
		 StringBuffer buff = new StringBuffer();
		 String uimResponseXml = "";
		 String content = "";
		 String updatedContent="";
		 OutputStreamWriter out = null;
		 BufferedReader in = null;
		 HttpURLConnection httpConn = connection.getConnection(prop.getProperty(UIMConstants.baseUrl),prop.getProperty(UIMConstants.action),prop.getProperty(UIMConstants.method));
		 String securityHeaderXml = "<soapenv:Header><wsse:Security soapenv:mustUnderstand=\"0\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">" +
		 		"<wsse:UsernameToken wsu:Id=\"UsernameToken-1\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\"><wsse:Username>"+prop.getProperty(UIMConstants.username)+"</wsse:Username>" +
		 		"<wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText\">"+prop.getProperty(UIMConstants.password)+"</wsse:Password></wsse:UsernameToken></wsse:Security></soapenv:Header>";
		 
		 if (uimRequestXml instanceof TextMessage) {
		    try {
				content=((TextMessage)uimRequestXml).getText().trim();
				updatedContent = content.replaceFirst("(?=.*?)<soapenv:Header>.*</soapenv:Header>(?=.*?)", securityHeaderXml);
			} catch (JMSException e) {
				e.printStackTrace();
			}
		 }
		 if (log.isDebugEnabled()) {
			 log.debug("UIM Request XML :::::::: \n"+updatedContent+"\n\n");
		 }
		 try {
			 if(httpConn != null && updatedContent.length()>0){
				out = new OutputStreamWriter(httpConn.getOutputStream());
				out.write(updatedContent, 0, updatedContent.length());
				out.flush();
				InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
				in = new BufferedReader(isr);
				String inputLine;
				while ((inputLine = in.readLine()) != null) {
					buff.append(inputLine);
				}
			 }
			 int responseCode = httpConn.getResponseCode();
			 uimResponseXml = buff.toString();
			 if (log.isDebugEnabled()) {
			   log.debug("UIM Response Code " + responseCode);
			 }
		 } catch (IOException e) {
			e.printStackTrace();
		 } finally{
			 if(out != null){
				 out.close();
			 }
			 if(in != null){
				 in.close();
			 }
			 if(httpConn != null){
				httpConn.disconnect();
			 }
		 }
		 if (log.isDebugEnabled()) {
			 log.debug("UIM Response XML :::::::: \n"+uimResponseXml+"\n\n");
		 }
		 if (log.isDebugEnabled()) {
			 log.debug("Leaving from OSMUIMMessageListener getResponse()");
		 }
		 return uimResponseXml;
	}
}
