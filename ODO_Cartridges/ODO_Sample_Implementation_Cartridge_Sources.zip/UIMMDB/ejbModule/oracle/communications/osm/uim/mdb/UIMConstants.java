package oracle.communications.osm.uim.mdb;

public class UIMConstants {

	public UIMConstants() {
		super();
	}
	
	public static final String configFileName = "uimconfig.properties";
	public static final String contentType = "application/soap+xml;charset=UTF-8";
	public static final String baseUrl = "uim_sf_ws_url";
	public static final String action = "action";
	public static final String method = "method";
	public static final String username = "username";
	public static final String password = "password";
}
