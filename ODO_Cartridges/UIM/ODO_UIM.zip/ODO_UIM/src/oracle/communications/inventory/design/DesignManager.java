package oracle.communications.inventory.design;

import java.util.List;

import oracle.communications.inventory.api.entity.ServiceConfigurationVersion;
import oracle.communications.inventory.api.exception.ValidationException;
import oracle.communications.inventory.api.framework.logging.Log;
import oracle.communications.inventory.api.framework.logging.LogFactory;
import oracle.communications.inventory.api.util.Utils;
import oracle.communications.inventory.xmlbeans.BusinessInteractionItemType;
import oracle.communications.inventory.xmlbeans.ParameterType;
import oracle.communications.inventory.xmlbeans.ServiceType;

import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlString;

public class DesignManager  {
	protected static final Log log = LogFactory.getLog(DesignManager.class);
	private String action = null;
	ServiceType service = null;
	XmlString customerIdParam = null;
	
	public DesignManager() {
	}

	/**
	 * Entry point for Design and Assign Service Fulfillment for ODO. 
	 * @param config the service configuration version being designed
	 * @param itemType the business interaction item type
	 * @return the designed service configuration version
	 * @throws Exception if any exceptions found
	 * @throws ValidationException if any validation exceptions found
	 */
	public ServiceConfigurationVersion design(ServiceConfigurationVersion config,
			BusinessInteractionItemType orderItem) throws Exception, ValidationException {
		
		/*
		 * Service configuration is required whether it is called from UI or
		 * web service. If orderItem is null, it means that this method is
		 * called from the UI. If orderItem is given, it can assign/reference
		 * resources to service based on order info.
		 */
		if (config == null)
			log.validationException("Configuration is Null.",
					null, new java.lang.IllegalArgumentException(), null);

		if (orderItem != null) {
			parseParameters(orderItem);
		}	
		
		config.getService().setId(customerIdParam.getStringValue());
		
		return config;
		
	}
		
		/**
		 * Parse the action parameters from the inbound request and make the
		 * parameter values available conveniently as fields on this object.
		 * 
		 * @param orderItem
		 *            the order item carrying the inbound request
		 * @throws ValidationException
		 *             a parameter does not match the action signature (e.g., it has
		 *             a type mismatch)
		 */
		protected void parseParameters(BusinessInteractionItemType orderItem)
				throws ValidationException {
			this.service = orderItem.getService();
			if (this.service == null) {
				log.validationException("Service is Null.",
						new java.lang.IllegalArgumentException("service"), null);
			}

			this.action = service.getAction();
			if (Utils.isEmpty(this.action))
				log.validationException("Invalid Service Action. ",
						new java.lang.IllegalArgumentException("action"), null);

			List params = orderItem.getParameterList();
			if (Utils.isEmpty(params))
				return;
			
			int size = params.size();
			for (int i=0;i<size;i++) {
				ParameterType param = (ParameterType)params.get(i);
				XmlObject paramValue = param.getValue();
				if (param.getName().equals("CustomerID")) {
					if (paramValue instanceof XmlString) {
						customerIdParam = (XmlString) paramValue;
					} else {
						log.validationException("Invalid Customer Id. ",
								new java.lang.IllegalArgumentException("parameter"), null);
					}
				}
			}
		}

}


